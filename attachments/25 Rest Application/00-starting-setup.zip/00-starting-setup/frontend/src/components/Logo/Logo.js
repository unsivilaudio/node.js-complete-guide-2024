import React from 'react';

import './Logo.css';

function Logo(props) {
    return <h1 className="logo">MessageNode</h1>;
}

export default Logo;
